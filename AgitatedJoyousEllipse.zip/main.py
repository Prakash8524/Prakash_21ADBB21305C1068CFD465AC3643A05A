def Hello_Woeld():
  print("Hello World ")

Hello_World()